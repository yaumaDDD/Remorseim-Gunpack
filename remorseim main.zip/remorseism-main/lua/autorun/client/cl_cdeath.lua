if not CLIENT then return end


local CLICK_SOUND         = "player/dfujiclick.wav"
local STAGE_1_DURATION    = 0
local STAGE_1_MIN_DIST    = 60
local STAGE_1_MAX_DIST    = 120
local STAGE_1_MIN_HEIGHT  = -20
local STAGE_1_MAX_HEIGHT  = 0
local STAGE_1_LOOK_HEIGHT = 15
local BLACK_FADE_DURATION = 7
local BLACK_FADE_OUT_DURATION = 2
local REALISH_BLACK_FADE_DURATION = 0.35
local REALISH_BLACK_FADE_OUT_DURATION = 0.45
local DEATH_TEXT_FADE_IN  = 1
local OPTIONS_FADE_IN     = 1.0
local TRANSITION_DURATION = 0.6
local DOUBLE_CLICK_WINDOW = 0.5

local DEATH_SOUNDS = {
    [0] = "rem_brutaldeath.mp3",
}


local cfg_spectator     = true
local cfg_compat        = false
local cfg_options_delay = 4
local cfg_realish       = false

net.Receive("DeathEffect_Config", function()
    cfg_spectator     = net.ReadBool()
    cfg_compat        = net.ReadBool()
    cfg_options_delay = net.ReadFloat()
    cfg_realish       = net.ReadBool()




    timer.Simple(0, function()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        if not ply:Alive() and not isDead then



            ply.DeathEffect_ServerDeathSignal = CurTime()
        end
    end)
end)


CreateClientConVar(
    "deatheffect_cam_max_dist", "150",
    true, false,
    "maximum camera follow distance in stage 2",
    40, 2000
)
CreateClientConVar(
    "deatheffect_cam_min_dist", "60",
    true, false,
    "minimum camera follow distance in stage 2",
    0, 2000
)
CreateClientConVar(
    "deatheffect_alt_sound", "0",
    true, false,
    "use the quieter death sound",
    0, 1
)
CreateClientConVar(
    "deatheffect_death_screen", "1",
    true, false,
    "enable the cinematic death screen",
    0, 1
)

local cv_cam_max_dist = GetConVar("deatheffect_cam_max_dist")
local cv_cam_min_dist = GetConVar("deatheffect_cam_min_dist")
local cv_alt_sound    = GetConVar("deatheffect_alt_sound")
local cv_death_screen = GetConVar("deatheffect_death_screen")

surface.CreateFont("DeathEffect_Key", { font = "Roboto", size = 52, weight = 700 })
surface.CreateFont("DeathEffect_Label", { font = "Roboto", size = 22, weight = 400 })
surface.CreateFont("DeathEffect_Hint", { font = "Roboto", size = 17, weight = 300 })

local hg_font = ConVarExists("hg_font") and GetConVar("hg_font") or nil
surface.CreateFont("DeathEffect_HG", { font = (hg_font and hg_font:GetString() ~= "" and hg_font:GetString()) or "Lora", size = 52, weight = 400, antialias = true })
surface.CreateFont("DeathEffect_HG_Large", { font = (hg_font and hg_font:GetString() ~= "" and hg_font:GetString()) or "Lora", size = 120, weight = 400, antialias = true })
surface.CreateFont("DeathEffect_HG_Desc", { font = (hg_font and hg_font:GetString() ~= "" and hg_font:GetString()) or "Lora", size = 28, weight = 400, antialias = true })


local function LookupKey(binding)
    local key = input.LookupBinding("+" .. binding) or input.LookupBinding(binding)
    if not key or key == "" then return KEY_UNKNOWN, "?" end
    return input.GetKeyCode(key), string.upper(key)
end

local reloadKeyCode, reloadKeyName = LookupKey("reload")
local jumpKeyCode,   jumpKeyName   = LookupKey("jump")
local crouchKeyCode, crouchKeyName = LookupKey("duck")
local sprintKeyCode, sprintKeyName = LookupKey("speed")

local function SafeKeyDown(code)
    if not code or code == KEY_UNKNOWN then return false end
    return input.IsButtonDown(code)
end

local m_pitch = GetConVar("m_pitch")
local m_yaw   = GetConVar("m_yaw")

local hasSpawned    = false
local isDead        = false
local stage2Started = false
local deathTime     = 0
local stage2Time    = 0
local autoCompatTriggered = false
local deathCamPos   = Vector(0, 0, 0)
local deathCamAng   = Angle(0, 0, 0)
local deathPos      = Vector(0, 0, 0)
local ragdollEnt    = nil
local matWhite      = Material("models/debug/debugwhite")

local deathSoundChannels = {}
local keepSoundAlive    = false

local inTransition        = false
local transitionStartTime = 0
local transitionCallback  = nil
local transitionFired     = false

local prevReloadDown = false
local prevJumpDown   = false

local compatActive     = false
local compatActiveTime = 0
local compatTriggered  = false

local inSpectator         = false
local freecamPos          = Vector(0, 0, 0)
local freecamAng          = Angle(0, 0, 0)
local lastReloadPressTime = 0
local prevSpecReloadDown  = false
local nextCamSync         = 0
local nextSoundfade       = 0


local zcity_RenderScene = nil
local zcity_CalcView = nil

local function TakeAuthority()
    local hooks = hook.GetTable()
    if hooks["RenderScene"] and hooks["RenderScene"]["jopa"] then
        zcity_RenderScene = hooks["RenderScene"]["jopa"]
        hook.Remove("RenderScene", "jopa")
    end
    if hooks["CalcView"] and hooks["CalcView"]["homigrad-view"] then
        zcity_CalcView = hooks["CalcView"]["homigrad-view"]
        hook.Remove("CalcView", "homigrad-view")
    end
end

local function ReleaseAuthority()
    if zcity_RenderScene then
        hook.Add("RenderScene", "jopa", zcity_RenderScene)
        zcity_RenderScene = nil
    end
    if zcity_CalcView then
        hook.Add("CalcView", "homigrad-view", zcity_CalcView)
        zcity_CalcView = nil
    end
end

local function DeathEffectRoundActive()
    if zb and zb.ROUND_STATE ~= nil then
        return zb.ROUND_STATE == 1
    end

    return true
end

local function DeathScreenEnabled()
    return not cv_death_screen or cv_death_screen:GetBool()
end

local function RealishDeathEffect()
    return cfg_realish or zb and zb.CROUND == "realish"
end

cvars.AddChangeCallback("deatheffect_death_screen", function(_, _, newValue)
    if newValue == "0" then
        ReleaseAuthority()
    elseif isDead and not compatActive then
        TakeAuthority()
    end
end, "DeathEffect_DeathScreenToggle")


local function PlayClick()
    sound.PlayFile("sound/" .. CLICK_SOUND, "noplay", function(ch)
        if IsValid(ch) then ch:Play() end
    end)
end

local function DoRespawn()
    net.Start("DeathEffect_Respawn")
    net.SendToServer()
end

local function EnterSpectator()
    inSpectator  = true
    freecamPos   = Vector(deathCamPos.x, deathCamPos.y, deathCamPos.z)
    freecamAng   = Angle(deathCamAng.pitch, deathCamAng.yaw, deathCamAng.roll)
    nextCamSync  = 0
    inTransition = false
    LocalPlayer():SetDSP(0)
    LocalPlayer():ConCommand("soundfade 0 1")
    net.Start("DeathEffect_EnterSpectator")
    net.SendToServer()
end

local function ActivateCompatMode()
    compatActive     = true
    compatActiveTime = CurTime()
    inTransition     = false
    LocalPlayer():SetDSP(0)
    LocalPlayer():ConCommand("soundfade 0 1")
    ReleaseAuthority() 
    net.Start("DeathEffect_CompatUnblock")
    net.SendToServer()
end

local function BeginTransition(callback)
    inTransition        = true
    transitionStartTime = CurTime()
    transitionCallback  = callback
    transitionFired     = false
    PlayClick()
end

local function InitDeathSequence(ply)
    if isDead then return end
    isDead           = true
    if DeathScreenEnabled() and not RealishDeathEffect() then
        TakeAuthority()
    end
    stage2Started    = false
    keepSoundAlive   = true
    inTransition     = false
    inSpectator      = false
    autoCompatTriggered = false
    compatActive     = false
    compatActiveTime = 0
    compatTriggered  = false
    deathTime        = CurTime()
    ragdollEnt       = ply:GetRagdollEntity()
    prevReloadDown   = false
    prevJumpDown     = false
    prevSpecReloadDown = false

    local plyPos = ply:GetPos()
    deathPos     = plyPos

    local randYaw  = math.random(0, 360)
    local randDist = math.random(STAGE_1_MIN_DIST, STAGE_1_MAX_DIST)
    local offset   = Vector(
        math.cos(math.rad(randYaw)) * randDist,
        math.sin(math.rad(randYaw)) * randDist,
        math.random(STAGE_1_MIN_HEIGHT, STAGE_1_MAX_HEIGHT)
    )

    local traceStart = plyPos + Vector(0, 0, 40)
    
    local tr = util.TraceLine({
        start  = traceStart,
        endpos = traceStart + offset,
        mask   = MASK_SOLID_BRUSHONLY
    })

    deathCamPos = tr.HitPos + tr.HitNormal * 5
    deathCamAng = (plyPos + Vector(0, 0, STAGE_1_LOOK_HEIGHT) - deathCamPos):Angle()

    deathSoundChannels = {}
    for _, deathSound in pairs(DEATH_SOUNDS) do
        sound.PlayFile("sound/" .. deathSound, "noplay", function(station)
            if IsValid(station) then
                deathSoundChannels[#deathSoundChannels + 1] = station
                station:Play()
            end
        end)
    end
end


local function CinematicDeathTracker()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    if not DeathEffectRoundActive() then
        hasSpawned = ply:Alive()

        if isDead then
            isDead = false
            stage2Started = false
            keepSoundAlive = false
            inTransition = false
            inSpectator = false
            autoCompatTriggered = false
            compatActive = false
            ReleaseAuthority()

            if IsValid(ragdollEnt) then
                ragdollEnt:SetNoDraw(false)
            end
            ragdollEnt = nil

            ply:SetDSP(0)
            ply:ConCommand("soundfade 0 1")

            for _, station in ipairs(deathSoundChannels) do
                if IsValid(station) then
                    station:Stop()
                end
            end
            deathSoundChannels = {}

            if ply:GetNWBool("DeathEffect_BlockRespawn", false) then
                net.Start("DeathEffect_CompatUnblock")
                net.SendToServer()
            end
        end

        return
    end

    if isDead and input.IsButtonDown(KEY_BACKSPACE) then
        isDead = false
        hasSpawned = false
        ReleaseAuthority()
        ply:SetDSP(0)
        ply:ConCommand("soundfade 0 1")
        if IsValid(ragdollEnt) then
            ragdollEnt:SetNoDraw(false)
        end
        if IsValid(deathSoundChannel) then
            deathSoundChannel:Stop()
            deathSoundChannel = nil
        end

        if ply:GetNWBool("DeathEffect_BlockRespawn", false) then
            net.Start("DeathEffect_CompatUnblock")
            net.SendToServer()
        end
        return
    end

    if ply:Alive() and not hasSpawned then
        hasSpawned = true
    end

    if not ply:Alive() and not isDead and hasSpawned then
        InitDeathSequence(ply)
    elseif not ply:Alive() and not isDead and ply:GetNWBool("DeathEffect_BlockRespawn", false) then



        if not ply.DeathEffect_ClientBlockStart then
            ply.DeathEffect_ClientBlockStart = CurTime()
        end
        if (CurTime() - ply.DeathEffect_ClientBlockStart) > 0.5 or ply.DeathEffect_ServerDeathSignal then

            if ply.DeathEffect_ServerDeathSignal and (CurTime() - ply.DeathEffect_ServerDeathSignal) < 5 then
                InitDeathSequence(ply)
                ply.DeathEffect_ClientBlockStart = nil
                ply.DeathEffect_ServerDeathSignal = nil
            elseif (CurTime() - ply.DeathEffect_ClientBlockStart) > 0.5 then
                InitDeathSequence(ply)
                ply.DeathEffect_ClientBlockStart = nil
                ply.DeathEffect_ServerDeathSignal = nil
            end
        end
    else
        if ply:GetNWBool("DeathEffect_BlockRespawn", false) and ply:Alive() then

            ply.DeathEffect_ClientBlockStart = nil
            ply.DeathEffect_ServerDeathSignal = nil
        elseif not ply:GetNWBool("DeathEffect_BlockRespawn", false) then
            ply.DeathEffect_ClientBlockStart = nil

            if ply.DeathEffect_ServerDeathSignal and (CurTime() - ply.DeathEffect_ServerDeathSignal) > 5 then
                ply.DeathEffect_ServerDeathSignal = nil
            end
        end
    end

    if ply:Alive() and isDead then
        isDead         = false
        stage2Started  = false
        keepSoundAlive = false
        inTransition   = false
        inSpectator    = false
        autoCompatTriggered = false
        compatActive   = false
        ReleaseAuthority() 
        
        if IsValid(ragdollEnt) then
            ragdollEnt:SetNoDraw(false)
        end
        ragdollEnt = nil

        ply:SetDSP(0)
        ply:ConCommand("soundfade 0 1")

        for _, station in ipairs(deathSoundChannels) do
            if IsValid(station) then
                station:Stop()
            end
        end
        deathSoundChannels = {}
    end

    if isDead and not stage2Started then
        if (CurTime() - deathTime) >= STAGE_1_DURATION then
            stage2Started = true
            stage2Time    = CurTime()
            if DeathScreenEnabled() and not RealishDeathEffect() then
                LocalPlayer():SetDSP(17)
                LocalPlayer():ConCommand("soundfade 100 99999")
            end
        end
    end


    if isDead and not compatActive and DeathScreenEnabled() and not RealishDeathEffect() then
        ply:SetViewPunchAngles(Angle(0,0,0))
        ply:ScreenFade(SCREENFADE.IN, Color(0,0,0,0), 0.1, 0)
        
        if stage2Started and not inSpectator then
            ply:SetDSP(17)

            if CurTime() >= nextSoundfade then
                nextSoundfade = CurTime() + 0.5
                ply:ConCommand("soundfade 100 99999")
            end
        end
    end

    if isDead and keepSoundAlive then
        local t = CurTime() - deathTime
        local anyPlaying = false
        for _, station in ipairs(deathSoundChannels) do
            if IsValid(station) and t < station:GetLength() then
                anyPlaying = true
                if station:GetState() ~= 1 then
                    station:Play()
                    station:SetTime(t, false)
                end
            end
        end
        if #deathSoundChannels > 0 and not anyPlaying then
            keepSoundAlive = false
        end
    end

    if isDead and not IsValid(ragdollEnt) then
        ragdollEnt = ply:GetRagdollEntity()
        if not IsValid(ragdollEnt) then
            local bestDist = math.huge
            for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do
                if ent:GetModel() == ply:GetModel() then
                    local dist = ent:GetPos():DistToSqr(deathPos)
                    if dist < 100000 and dist < bestDist then
                        ragdollEnt = ent
                        bestDist   = dist
                    end
                end
            end
        end
    end

    if inTransition and not transitionFired then
        if (CurTime() - transitionStartTime) >= TRANSITION_DURATION then
            transitionFired = true
            PlayClick()
            if transitionCallback then
                transitionCallback()
                transitionCallback = nil
            end
        end
    end

    if isDead and stage2Started and not autoCompatTriggered then
        local fadeDuration = RealishDeathEffect() and REALISH_BLACK_FADE_DURATION or BLACK_FADE_DURATION
        local fadeOutDuration = RealishDeathEffect() and REALISH_BLACK_FADE_OUT_DURATION or BLACK_FADE_OUT_DURATION

        if (CurTime() - stage2Time) >= (fadeDuration + fadeOutDuration) then
            autoCompatTriggered = true
            ActivateCompatMode()
        end
    end




    if not isDead and not ply:Alive() and ply:GetNWBool("DeathEffect_BlockRespawn", false) then
        if ply.DeathEffect_ClientBlockStart and (CurTime() - ply.DeathEffect_ClientBlockStart) > 8 then
            ply.DeathEffect_ClientBlockStart = nil
            ply.DeathEffect_ServerDeathSignal = nil
            net.Start("DeathEffect_CompatUnblock")
            net.SendToServer()
        end
    end

    if inSpectator and not inTransition then
        local reloadDown = SafeKeyDown(reloadKeyCode)

        if reloadDown and not prevSpecReloadDown then
            local now = CurTime()
            if (now - lastReloadPressTime) <= DOUBLE_CLICK_WINDOW then
                BeginTransition(DoRespawn)
            else
                lastReloadPressTime = now
            end
        end

        prevSpecReloadDown = reloadDown

        local timeNow = CurTime()
        if timeNow >= nextCamSync then
            nextCamSync = timeNow + 0.05
            net.Start("DeathEffect_UpdateCam")
                net.WriteVector(freecamPos)
                net.WriteAngle(freecamAng)
            net.SendToServer()
        end
    end
end
hook.Add("Think", "CinematicDeathTracker", CinematicDeathTracker)


local function CinematicDeathFreecamLook(cmd)
    if not inSpectator then return end
    local mX = cmd:GetMouseX()
    local mY = cmd:GetMouseY()
    freecamAng.pitch = math.Clamp(freecamAng.pitch + mY * m_pitch:GetFloat(), -89, 89)
    freecamAng.yaw   = freecamAng.yaw - mX * m_yaw:GetFloat()
    freecamAng.roll  = 0
    cmd:SetViewAngles(freecamAng)
end
hook.Add("CreateMove", "CinematicDeathFreecamLook", CinematicDeathFreecamLook)


local function BuildDeathView(fov)
    if not DeathScreenEnabled() then return end
    if RealishDeathEffect() then return end

    if compatActive then 
        return {
            origin     = LocalPlayer():EyePos(),
            angles     = LocalPlayer():EyeAngles(),
            fov        = fov,
            drawviewer = false,
        }
    end

    if inSpectator then
        local dt        = FrameTime()
        local speedMult = SafeKeyDown(sprintKeyCode) and 3 or 1
        local speed     = 200 * dt * speedMult
        local fwd       = freecamAng:Forward()
        local right     = freecamAng:Right()
        local up        = Vector(0, 0, 1)

        if input.IsButtonDown(KEY_W) then freecamPos = freecamPos + fwd   * speed end
        if input.IsButtonDown(KEY_S) then freecamPos = freecamPos - fwd   * speed end
        if input.IsButtonDown(KEY_A) then freecamPos = freecamPos - right * speed end
        if input.IsButtonDown(KEY_D) then freecamPos = freecamPos + right * speed end
        if SafeKeyDown(jumpKeyCode)   then freecamPos = freecamPos + up   * speed end
        if SafeKeyDown(crouchKeyCode) then freecamPos = freecamPos - up   * speed end

        return { origin = freecamPos, angles = freecamAng, fov = fov, drawviewer = false }
    end

    local elapsed = CurTime() - deathTime
    local view = { origin = deathCamPos, fov = fov, drawviewer = false }

    if elapsed < STAGE_1_DURATION then
        local intensity = (1 - (elapsed / STAGE_1_DURATION)) * 15
        view.angles = deathCamAng + Angle(
            math.sin(CurTime() * 30) * intensity,
            math.cos(CurTime() * 35) * intensity,
            math.sin(CurTime() * 40) * intensity
        )
    else
        if IsValid(ragdollEnt) then
            local targetPos = ragdollEnt:GetPos() + Vector(0, 0, 15)
            local targetAng = (targetPos - deathCamPos):Angle()
            deathCamAng = LerpAngle(FrameTime() * 4, deathCamAng, targetAng)

            local dist = deathCamPos:Distance(targetPos)
            if dist > 0 then
                local dir    = (targetPos - deathCamPos):GetNormalized()
                local maxDist = cv_cam_max_dist and cv_cam_max_dist:GetFloat() or 150
                local minDist = cv_cam_min_dist and cv_cam_min_dist:GetFloat() or 40
                if dist > maxDist then
                    deathCamPos = LerpVector(FrameTime() * 2, deathCamPos, targetPos - dir * maxDist)
                elseif dist < minDist then
                    deathCamPos = LerpVector(FrameTime() * 2, deathCamPos, targetPos - dir * minDist)
                end
            end
        end
        view.origin = deathCamPos
        view.angles = deathCamAng
    end

    return view
end


local function CinematicDeathCamera(ply, pos, angles, fov)
    if not isDead then return end
    return BuildDeathView(fov)
end
hook.Add("CalcView", "CinematicDeathCamera", CinematicDeathCamera)

local function CinematicDeathHGCalcView(ply, origin, angles, fov, znear, zfar)
    if not isDead then return end
    return BuildDeathView(fov)
end
hook.Add("HG_CalcView", "CinematicDeathHGOverride", CinematicDeathHGCalcView)


local function CinematicDeathMute()
    if isDead and stage2Started and not inSpectator and not compatActive and DeathScreenEnabled() and not RealishDeathEffect() then
        return false
    end
end
hook.Add("EntityEmitSound", "CinematicDeathMute", CinematicDeathMute)

local function CinematicDeathHideRagdoll()
    if not isDead or not IsValid(ragdollEnt) or compatActive or not DeathScreenEnabled() or RealishDeathEffect() then return end
    
    if (CurTime() - deathTime) < STAGE_1_DURATION then
        ragdollEnt:SetNoDraw(true)
    else
        ragdollEnt:SetNoDraw(false)
    end
end
hook.Add("PreDrawOpaqueRenderables", "CinematicDeathHideRagdoll", CinematicDeathHideRagdoll)

local function CinematicDeathBackground()
    if not isDead or compatActive then return end

    local sw, sh  = ScrW(), ScrH()
    local elapsed = CurTime() - deathTime

    if inTransition then
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(0, 0, sw, sh)
        return
    end

    if inSpectator then
        local hint = "double click [" .. reloadKeyName .. "] to respawn"
        surface.SetFont("DeathEffect_Hint")
        local hw = surface.GetTextSize(hint)
        surface.SetTextColor(Color(180, 180, 180, 140))
        surface.SetTextPos(sw / 2 - hw / 2, 20)
        surface.DrawText(hint)
        return
    end

    if elapsed >= STAGE_1_DURATION then
        local stageElapsed = elapsed - STAGE_1_DURATION
        local realish = RealishDeathEffect()
        local fadeDuration = realish and REALISH_BLACK_FADE_DURATION or BLACK_FADE_DURATION
        local fadeOutDuration = realish and REALISH_BLACK_FADE_OUT_DURATION or BLACK_FADE_OUT_DURATION
        local fadeProgress = math.Clamp(stageElapsed / fadeDuration, 0, 1)
        local fadeOutProgress = math.Clamp((stageElapsed - fadeDuration) / fadeOutDuration, 0, 1)
		local overlayAlpha = realish and math.floor((fadeOutProgress > 0 and 1 - fadeOutProgress or fadeProgress) * 255) or math.floor((1 - fadeOutProgress) * 255)
        local red = realish and 0 or math.floor((1 - fadeProgress) * 255)
        surface.SetDrawColor(red, 0, 0, overlayAlpha)
        surface.DrawRect(0, 0, sw, sh)

        if realish then return end

        if not DeathScreenEnabled() then
            local textFadeIn = math.Clamp(stageElapsed / DEATH_TEXT_FADE_IN, 0, 1)
            local textAlpha = math.floor(textFadeIn * overlayAlpha * (1 - fadeProgress))
            local text = "Deceased."
            local desc = "You are no longer a witness to the world."
            draw.SimpleText(text, "DeathEffect_HG_Large", sw / 2, sh / 2 - 40, Color(0, 0, 0, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(desc, "DeathEffect_HG_Desc", sw / 2, sh / 2 + 45, Color(0, 0, 0, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            return
        end

        if fadeProgress < 1 and IsValid(ragdollEnt) then
            cam.Start3D(deathCamPos, deathCamAng)
                cam.IgnoreZ(true)
                render.SuppressEngineLighting(true)
                render.MaterialOverride(matWhite)
                render.SetColorModulation(0, 0, 0)
                render.SetBlend(1)
                ragdollEnt:DrawModel()
                render.SetBlend(1)
                render.SetColorModulation(1, 1, 1)
                render.MaterialOverride(nil)
                render.SuppressEngineLighting(false)
                cam.IgnoreZ(false)
            cam.End3D()
        end

        local textFadeIn = math.Clamp(stageElapsed / DEATH_TEXT_FADE_IN, 0, 1)
        local textAlpha = math.floor(textFadeIn * overlayAlpha * (1 - fadeProgress))
        local shake = 5 * (1 - textFadeIn)
        local text = "Deceased."
        local desc = "You are no longer a witness to the world."
        local slide = 1 - ((1 - textFadeIn) ^ 3)
        local textX = Lerp(slide, -650, 70) + math.sin(CurTime() * 95) * shake
        local textY = sh / 2 - 60 + math.cos(CurTime() * 110) * shake
        draw.SimpleText(text, "DeathEffect_HG_Large", textX, textY, Color(0, 0, 0, textAlpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(desc, "DeathEffect_HG_Desc", textX + 6, textY + 85, Color(0, 0, 0, textAlpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

end
hook.Add("DrawOverlay", "CinematicDeathBackground", CinematicDeathBackground)

local function HideDefaultDamage(name)
    if isDead and name == "CHudDamageIndicator" then return false end
end
hook.Add("HUDShouldDraw", "HideDefaultDamage", HideDefaultDamage)


local deathRenderView = {
    x = 0, y = 0, drawhud = true, drawviewmodel = false, dopostprocess = true, drawmonitors = true,
}
local renderingDeathView = false

local function CinematicDeathRenderScene(pos, angle, fov)
    if not isDead or renderingDeathView then return end

    local view = BuildDeathView(fov)
    if not view then return end

    deathRenderView.w          = ScrW()
    deathRenderView.h          = ScrH()
    deathRenderView.fov        = view.fov or fov
    deathRenderView.origin     = view.origin
    deathRenderView.angles     = view.angles
    deathRenderView.drawviewer = view.drawviewer

    renderingDeathView = true
    render.RenderView(deathRenderView)
    renderingDeathView = false

    return true
end
hook.Add("RenderScene", "CinematicDeathRenderScene", CinematicDeathRenderScene)